# Antakelser og kommentarer

Her kan dere skrive antakelser dere har gjort i l?pet av oppgaven. 


## Del 1

## Del 2

## Del 3

## Del 4

## Del 5
