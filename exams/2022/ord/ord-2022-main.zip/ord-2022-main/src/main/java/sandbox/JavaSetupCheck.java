package sandbox;

public class JavaSetupCheck {

	public static String helloWorld() {
		return "Gratulerer, Java-oppsettet ditt fungerer!";
	}

	public static void main(final String[] args) {
		System.out.println(helloWorld());
	}
}
