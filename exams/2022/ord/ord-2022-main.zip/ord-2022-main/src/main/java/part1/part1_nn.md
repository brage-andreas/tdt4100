Denne oppgåva handlar om to **Comparator*-implementasjoner for samanlikning og sortering av **Player*-instansar.
Vi spesifiserer ikkje korleis desse blir implementerte ut over at to metodar i BasketballComparators
skal returne kvar sin typa **Comparator*-instans*.

Fyll inn vedlagde [BasketballComparators](BasketballComparators.java), der det er markert med // TODO og dei to metodane der.

Du skal ta utgangspunkt i, men treng ikkje å endra **Player** og **PlayerGameStat** som ligg vedlagt.

Det er tillate å legga metodar til desse klassane dersom du meiner det er til hjelp (òg for testing).

For detaljer om åtferd, sjå javadoc.