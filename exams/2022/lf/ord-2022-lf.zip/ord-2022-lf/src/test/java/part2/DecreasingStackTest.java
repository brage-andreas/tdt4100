package part2;

public class DecreasingStackTest {
    //TODO
    
}
