## FXML App (15%)

Denne applikasjonen har eitt formål - å visa kvadratet av talet som blir skrive inn.

Det er nokre utfordringar med koden - finn dei og fiks dei!

![Døme 1:](App1.png)

![Døme 2:](App2.png)
