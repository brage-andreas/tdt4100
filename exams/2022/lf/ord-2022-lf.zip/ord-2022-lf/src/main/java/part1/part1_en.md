# Part 1 (15%)

This task involves two implementations of **Comparator**, for comparing and sorting of **Player** instances.

We do not specify how these are implemented, other than that the two methods in BaskeballComparators shall each return an **Comparator** instance as described in the javadoc. 

Write the code in the accompanying file [BasketballComparators](BasketballComparators.java), the two methods are marked with TODO.

Base your implementation on **Player** and **PlayerGameStat** classes. These you do not need to change these, but you are allowed to add methods if that is useful to you, also for testing purposes.

See the javadoc for furter details.
