# Del 1  (15 %)

Denne oppgaven handler om to **Comparator**-implementasjoner for sammenligning og sortering av **Player**-instanser.
Vi spesifiserer ikke hvordan disse implementeres ut over at to metoder i BasketballComparators
skal returne hver sin type **Comparator**-*instans*.

Fyll inn vedlagte [BasketballComparators](BasketballComparators.java), der det er markert med // TODO og de to metodene der.

Du skal ta utgangspunkt i, men trenger ikke å endre **Player** og **PlayerGameStat** som ligger vedlagt.

Det er tillatt å legge metoder til disse klassene dersom du mener det er til hjelp (også for testing).

For detaljer om oppførsel, se javadoc.
