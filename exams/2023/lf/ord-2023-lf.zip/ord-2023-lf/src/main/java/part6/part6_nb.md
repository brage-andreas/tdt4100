# Del 6 - BookingCanceler

1. Implementer `CheapestBookingCanceller` som implementerer `BookingCanceller`-grensesnittet. Denne klassen skal kansellere bestillingene med de laveste prisene.
   - 'cancelBookings'-metoden skal ta inn en *liste over bestillinger* og et heltall *numberToCancel*, og kansellere det angitte antallet bestillinger med de laveste prisene.
