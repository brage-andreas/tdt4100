# Part 6 - BookingCanceller


1. Implement `CheapestBookingCanceller` that implements the `BookingCanceller` interface. This class should cancel the bookings with the lowest price.
   - The `cancelBookings` method should take a list of bookings and an integer, `numberToCancel`, and cancel the specified number of bookings with the lowest price.
