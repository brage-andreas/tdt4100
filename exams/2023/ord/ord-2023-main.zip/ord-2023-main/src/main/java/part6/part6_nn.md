# Del 6 - BookingCanceler

1. Implementer `CheapestBookingCanceller` som implementerer `BookingCanceller`-grensesnittet. Denne klassen skal kansellere bestillingane med dei lågaste prisane.
   - 'cancelBookings'-metoden skal ta inn ei *liste over bestillinger* og eit heiltal *numberToCancel*, og kansellere det angitte antalet bestillinger med dei lågaste prisane.