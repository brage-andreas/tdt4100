# Antakelser og kommentarer

Her kan dere skrive antakelser dere har gjort i løpet av oppgaven. 


## Del 1

## Del 2

## Del 3

## Del 4

## Del 5

## Del 6

## Del 7

## Del 8

## Del 9