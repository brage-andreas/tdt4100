package com.bmw.manufacturing.part3;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

import org.junit.jupiter.api.Test;

import no.ntnu.tdt4100.part3.RandomGenerator;

@SuppressWarnings("unused")
class GlobalCarProductionRegistryTests {

    @Test
    void getNumberOfProducedUnits_should_return_the_correct_number() {
        // After implementing the getNumberOfProducedUnits method
        // uncomment the test and remove the assertFalse to run the test
        assertFalse(true);

        // long producedUnits = GlobalCarProductionRegistry.getNumberOfProducedUnits();
        // assertEquals(0, producedUnits);
        // for(int i = 0; i < 10; i++) {
        //     GlobalCarProductionRegistry.registerCarVin(null);
        // }
        // assertEquals(10, GlobalCarProductionRegistry.getNumberOfProducedUnits());
    }
}
