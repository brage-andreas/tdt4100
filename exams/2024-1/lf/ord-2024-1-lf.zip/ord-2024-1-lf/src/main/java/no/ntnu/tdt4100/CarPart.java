package no.ntnu.tdt4100;

/** 
 * Represents a car part.
 * 
 * THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
 */
public record CarPart(String partId, String partName, int unitCost) {}