package no.ntnu.tdt4100.part1;

/**
 * THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
 */
public interface ITask2 {
    default void count_up_box() {}
    void countInventory();
}
