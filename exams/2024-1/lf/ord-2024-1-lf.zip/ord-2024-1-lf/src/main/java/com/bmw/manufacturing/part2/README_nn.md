# Del 2 (20% av karakteren)

Denne delen handlar om klasse- og metodeerklæring, implementering av grensesnitt, bruk av streams og grunnleggjande Java-syntaks.

## Bakgrunn

Du skal implementere følgjande klasser.

* [CarFactory.java](CarFactory.java)
* [MainOffice.java](MainOffice.java)

JavaDoc i klassene over inneheld detaljar for å forstå krava til denne oppgåva og fullføre implementeringa av begge klassene.

# Testar
Nokre testar (ikkje komplett sett) er levert for å støtte deg i denne delen. Ver merksam på at nokre testar er kommenterte ut, avkommenter for å køyre dei.
* [Testar for CarFactory](../../../../../../test/java/com/bmw/manufacturing/part2/CarFactoryTests.java)
* [Testar for MainOffice](../../../../../../test/java/com/bmw/manufacturing/part2/MainOfficeTests.java)
