# Del 1 (20%)

BMW vil sikre at du har god forståing av Java-programmeringsspråket. Dei har laga 10 oppgåver for å teste kunnskapen din.

For kvar oppgåve må du avkommentere den riktige delen av den kommenterte koden for å fullføre oppgåva. Les instruksjonane i JavaDoc nøye for kvar oppgåve for å forstå den ønska oppførselen.

Du får poeng for kvar kommenterte linje der du heilt korrekt har fjerna kommentaren. Totalpoenga til oppgåva blir fordelt på kor mange rette svar det er i oppgåva. Viss du fjernar kommentar på ei linje som ikkje skal fjernast, då blir du trekt tilsvarande. Du kan ikkje få mindre enn 0 poeng per oppgåve.

# Oppgåver
* [Oppgåve 1](Task1.java)
* [Oppgåve 2](Task2.java)
* [Oppgåve 3](Task3.java)
* [Oppgåve 4](Task4.java)
* [Oppgåve 5](Task5.java)
* [Oppgåve 6](Task6.java)
* [Oppgåve 7](Task7.java)
* [Oppgåve 8](Task8.java)
* [Oppgåve 9](Task9.java)
* [Oppgåve 10](Task10.java)

# Einingstestar
Dei to første oppgåvene i del 1 er dekka av einingstestar.
Einingstestane er lokalisert i

* [Part1Tests](../../../../../../test/java/com/bmw/manufacturing/part1/Part1Tests.java)

Når testane er grønne (kjører utan feil), betyr det at du har avkommentert riktig svar.

Du kan kjøre testane ved å trykke på den grønne "Play"-knappen når du opnar testklassen.
Hugs at du òg kan skrive main-metodar for å hjelpe deg her.





