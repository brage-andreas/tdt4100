package com.bmw.manufacturing.part2;

/**
 * Implement the class MainOffice.
 * 
 * The class must implement the interface {@link no.ntnu.tdt4100.part2.IMainOffice}. 
 * The class needs no constructor.
 * 
 * Read the documentation in the {@link no.ntnu.tdt4100.part2.IMainOffice} interface 
 * for detailed description on expected behaviour 
 * of the methods you need to implement.
 * 
 * @see no.ntnu.tdt4100.part2.IMainOffice
 * @see MainOfficeTests
 */

 // TODO Implement the MainOffice class here according to description in JavaDoc
public class MainOffice {}