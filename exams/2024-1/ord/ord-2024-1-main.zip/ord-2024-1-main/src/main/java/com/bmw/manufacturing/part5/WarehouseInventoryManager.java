package com.bmw.manufacturing.part5;

/**
 * WarehouseInventoryManager must implement the {@link no.ntnu.tdt4100.part5.InventoryManager} interface
 * 
 * @see no.ntnu.tdt4100.part5.InventoryManager
 * @see WarehouseInventoryManagerTests
 */
public class WarehouseInventoryManager {
    // TODO Implement the class according to behaviour specified in Javadoc in its interface
}
