package no.ntnu.tdt4100;

/**
 * THIS IS SUPPLIED CODE, DO NOT EDIT THIS CODE
 */
public record Car(int weight, int value, String name) {}
