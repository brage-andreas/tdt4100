package com.mercedesbenz.part1;

import no.ntnu.tdt4100.part1.ITask02;

public class Task02 implements ITask02 {
    /**
     * This method should call count exactly 15 times
     * 
     * Comment out the line(s) that will make this method call count 15
     * times
     * 
     * @see Part1Tests
     */
    public void invoke() {
        // TODO Uncomment the line(s) that performs as specified in JavaDoc

        // for(int i=1; i < 15; ++i)
        // for(int i=0; i <= 15; ++i)
        // for(int i=0; i < 1515; i++)
        // for(int i=15; i <= 0; i++)
        for(int i=15; i > 0; i--)
        count();
    }
}

