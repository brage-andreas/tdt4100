# Del 2 (20% av poengsummen)

Denne delen handlar om klasse- og metodeerklæring, implementering av grensesnitt, bruk av straumar og grunnleggjande Java-syntaks.

## Bakgrunn

Du vil implementera følgjande klassar:

* [ResearchFacility.java](ResearchFacility.java)
* [GroupHeadquarters.java](GroupHeadquarters.java)

JavaDoc i klassane ovanfor inneheld detaljar for å forstå krava til denne oppgåva og fullføra implementeringa av begge klassane.

# Einingstestar

Noen einingstestar (ikkje komplett sett) er levert for å støtta deg for denne delen. Ver merksam på at nokre testar er kommenterte, fjern kommenteringa for å køyra dei.
* [Testar for ResearchFacility](../../../../../test/java/com/mercedesbenz/part2/ResearchFacilityTests.java)
* [Testar for GroupHeadquarters](../../../../../test/java/com/mercedesbenz/part2/GroupHeadquartersTests.java)