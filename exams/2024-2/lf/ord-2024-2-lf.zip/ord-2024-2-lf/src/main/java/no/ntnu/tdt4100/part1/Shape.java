package no.ntnu.tdt4100.part1;

public abstract class Shape {
    public double calculateArea() { return 0.0; }
}
