# Part 1 (20%)

Mercedes ønskjer å forsikra seg om at du har eit solid grep om programmeringsspråket Java. Dei har laga 10 oppgåver for å testa kunnskapen din.

For kvar oppgåve, må du fjerne kommenteringa frå den korrekte delen av den kommenterte koden for å fullføra oppgåva. Les instruksjonane i JavaDoc nøye for kvar oppgåve for å forstå den ønskte åtferda.

# Oppgåver
* [Oppgåve 1](Task01.java)
* [Oppgåve 2](Task02.java)
* [Oppgåve 3](Task03.java)
* [Oppgåve 4](Task04.java)
* [Oppgåve 5](Task05.java)
* [Oppgåve 6](Task06.java)
* [Oppgåve 7](Task07.java)
* [Oppgåve 8](Task08.java)
* [Oppgåve 9](Task09.java)
* [Oppgåve 10](Task10.java)

# Enhetstester
Dei to første oppgåvene i del 1 er dekt av einingstestar.
Einingstestane er plasserte i

* [Part1Tests](../../../../../test/java/com/mercedesbenz/part1/Part1Tests.java)

Når testane er grøne (køyrar utan feil), betyr det at du har fjerna kommenteringa frå det korrekte svaret.

Du kan køyra einingstesten ved å trykkja på dei grøne "Play"-knappane når du opnar testklassen. Hugs at du også kan skriva main-metoder for å hjelpa deg her.