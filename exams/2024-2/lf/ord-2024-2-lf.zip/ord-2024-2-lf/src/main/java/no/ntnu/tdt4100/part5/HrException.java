package no.ntnu.tdt4100.part5;

/** 
* THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
*/
public class HrException extends RuntimeException {
    
}
