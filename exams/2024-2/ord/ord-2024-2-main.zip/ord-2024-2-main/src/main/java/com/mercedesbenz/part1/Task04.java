package com.mercedesbenz.part1;

import no.ntnu.tdt4100.part1.AbstractTask04;

public class Task04 extends AbstractTask04 {

    /**
     * Read carefully the statements below.
     * 
     * Comment out the line(s) that are true.
     */
    public void classy_classes() {
        // TODO Uncomment the line(s) that are true
        
        // A_class_cannot_be_instantiated_outside_its_package_unless_it_has_a_public_modifier();
        // A_class_can_extend_multiple_classes();
        // An_abstract_class_must_include_at_least_1_abstract_method();
        // The_Override_annotation_must_be_used_when_overriding_methods_from_parent_classes();
        // If_a_superclass_has_a_declared_constructor_a_subclass_must_also_declare_a_constructor();
        // A_class_can_implement_only_one_interface();
    }
}