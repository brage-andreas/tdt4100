package com.mercedesbenz.part2;

/**
 * Implement the class GroupHeadquarters
 * 
 * The class must implement the interface {@link no.ntnu.tdt4100.part2.IGroupHeadquarters}. 
 * 
 * @see GroupHeadquartersTests
 */
public class GroupHeadquarters {
    // TODO Implement the class according to JavaDoc
}
