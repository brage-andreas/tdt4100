
package no.ntnu.tdt4100.part3;

/**
 * THIS CODE IS SUPPLIED, DO NOT MODIFY
 */
public interface SecretCode {
    public static char[] WIPE_CODE = "prettyweakcode".toCharArray();
}
