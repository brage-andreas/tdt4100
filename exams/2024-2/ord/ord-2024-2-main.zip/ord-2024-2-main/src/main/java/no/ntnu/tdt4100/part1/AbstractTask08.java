package no.ntnu.tdt4100.part1;

/**
 * THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
 */
public abstract class AbstractTask08 {
    public int[] checkboxes = new int[6];

    public void A_fillA() { checkboxes[0] = 1; }
    public void B_fillB() { checkboxes[1] = 1; }
    public void C_fillC() { checkboxes[2] = 1; }
    public void D_fillD() { checkboxes[3] = 1; }
    public void E_fillE() { checkboxes[4] = 1; }
    public void F_fillF() { checkboxes[5] = 1;}
}