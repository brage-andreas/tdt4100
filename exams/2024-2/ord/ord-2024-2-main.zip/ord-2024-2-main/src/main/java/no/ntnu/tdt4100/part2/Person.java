package no.ntnu.tdt4100.part2;

/**
* THIS CODE IS SUPPLIED, DO NOT MODIFY
*/
public record Person(String name, Role role) {}
