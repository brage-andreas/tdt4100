package no.ntnu.tdt4100.part2;

/*
* THIS CODE IS SUPPLIED, DO NOT MODIFY
*/
public enum Role {
    DEPARTMENT_LEAD,
    PROJECT_LEAD,
    HR_MANAGER,
    FACILITY_MANAGER,
    RESEARCHER
}