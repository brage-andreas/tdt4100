package no.ntnu.tdt4100.part1;

/**
 * THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
 */
public abstract class AbstractTask10 {
    public abstract String print(String greet, String name);

    public int[] checkboxes = new int[5];
    public void A__empty_string() {checkboxes[0] = 1;}
    public void B__nope() {checkboxes[1] = 1;}
    public void C__saywhat() {checkboxes[2] = 1;}
    public void D__its_either_A_B_or_C_but_we_must_run_the_program_to_determine_which() {checkboxes[3] = 1;}
    public void E__none_because_given_specific_input_values_the_method_might_throw_an_error() {checkboxes[4] = 1;}
}
