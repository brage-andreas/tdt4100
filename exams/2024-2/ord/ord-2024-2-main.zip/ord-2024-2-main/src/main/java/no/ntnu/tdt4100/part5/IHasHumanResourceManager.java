package no.ntnu.tdt4100.part5;

/**
 * THIS IS SUPPLIED CODE, DO NOT MODIFY THIS CODE
 */
public interface IHasHumanResourceManager {
    /**
     * Returns the HR manager
     * @return the {@link IHumanResourceManager}
     */
    IHumanResourceManager getHumanResourceManager();
}
